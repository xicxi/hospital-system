import { get, post } from '/@/utils/http/axios';

const URL = {
  list: '/myapp/admin/comment/list',
  create: '/myapp/admin/comment/create',
  delete: '/myapp/admin/comment/delete',
  listThingComments: '/api/comment/listThingComments',
  listUserComments: '/api/comment/listUserComments',
  like: '/api/comment/like',
};

const listApi = async (params) => get({ url: URL.list, params: params, data: {}, headers: {} });
const createApi = async (data) =>
  post({
    url: URL.create,
    params: {},
    data: data,
    headers: { 'Content-Type': 'multipart/form-data;charset=utf-8' },
  });
const deleteApi = async (params) => post({ url: URL.delete, params: params, headers: {} });
const listThingCommentsApi = async (params) => get({ url: URL.listThingComments, params: params, data: {}, headers: {} });
const listUserCommentsApi = async (params) => get({ url: URL.listUserComments, params: params, data: {}, headers: {} });
const likeApi = async (params) => post({ url: URL.like, params: params, headers: {} });

export { listApi, createApi, deleteApi, listThingCommentsApi, listUserCommentsApi, likeApi };

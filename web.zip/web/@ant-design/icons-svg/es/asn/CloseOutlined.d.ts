import { IconDefinition } from '../types';
declare const CloseOutlined: IconDefinition;
export default CloseOutlined;

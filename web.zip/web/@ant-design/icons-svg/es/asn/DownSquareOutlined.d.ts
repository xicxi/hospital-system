import { IconDefinition } from '../types';
declare const DownSquareOutlined: IconDefinition;
export default DownSquareOutlined;

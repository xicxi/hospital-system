import { IconDefinition } from '../types';
declare const InfoOutlined: IconDefinition;
export default InfoOutlined;

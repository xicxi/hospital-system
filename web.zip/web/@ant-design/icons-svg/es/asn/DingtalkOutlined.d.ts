import { IconDefinition } from '../types';
declare const DingtalkOutlined: IconDefinition;
export default DingtalkOutlined;

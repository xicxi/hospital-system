import { IconDefinition } from '../types';
declare const EditTwoTone: IconDefinition;
export default EditTwoTone;

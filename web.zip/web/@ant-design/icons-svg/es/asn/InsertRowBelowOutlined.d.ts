import { IconDefinition } from '../types';
declare const InsertRowBelowOutlined: IconDefinition;
export default InsertRowBelowOutlined;

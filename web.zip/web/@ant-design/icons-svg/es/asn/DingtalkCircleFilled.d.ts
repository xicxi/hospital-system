import { IconDefinition } from '../types';
declare const DingtalkCircleFilled: IconDefinition;
export default DingtalkCircleFilled;

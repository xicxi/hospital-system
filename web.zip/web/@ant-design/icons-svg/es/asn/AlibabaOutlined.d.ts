import { IconDefinition } from '../types';
declare const AlibabaOutlined: IconDefinition;
export default AlibabaOutlined;

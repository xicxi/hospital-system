import { IconDefinition } from '../types';
declare const GooglePlusOutlined: IconDefinition;
export default GooglePlusOutlined;

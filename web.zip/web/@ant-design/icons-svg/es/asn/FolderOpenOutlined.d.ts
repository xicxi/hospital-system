import { IconDefinition } from '../types';
declare const FolderOpenOutlined: IconDefinition;
export default FolderOpenOutlined;

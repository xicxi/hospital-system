import { IconDefinition } from '../types';
declare const FireTwoTone: IconDefinition;
export default FireTwoTone;

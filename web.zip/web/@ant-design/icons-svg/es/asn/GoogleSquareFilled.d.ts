import { IconDefinition } from '../types';
declare const GoogleSquareFilled: IconDefinition;
export default GoogleSquareFilled;

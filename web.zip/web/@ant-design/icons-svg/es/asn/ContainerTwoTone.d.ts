import { IconDefinition } from '../types';
declare const ContainerTwoTone: IconDefinition;
export default ContainerTwoTone;

import { IconDefinition } from '../types';
declare const InsuranceOutlined: IconDefinition;
export default InsuranceOutlined;

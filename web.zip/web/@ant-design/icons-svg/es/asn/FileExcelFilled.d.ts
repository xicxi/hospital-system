import { IconDefinition } from '../types';
declare const FileExcelFilled: IconDefinition;
export default FileExcelFilled;

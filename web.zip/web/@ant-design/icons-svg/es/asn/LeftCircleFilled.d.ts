import { IconDefinition } from '../types';
declare const LeftCircleFilled: IconDefinition;
export default LeftCircleFilled;

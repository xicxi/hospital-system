import { IconDefinition } from '../types';
declare const EnvironmentTwoTone: IconDefinition;
export default EnvironmentTwoTone;

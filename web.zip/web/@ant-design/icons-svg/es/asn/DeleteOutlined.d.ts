import { IconDefinition } from '../types';
declare const DeleteOutlined: IconDefinition;
export default DeleteOutlined;

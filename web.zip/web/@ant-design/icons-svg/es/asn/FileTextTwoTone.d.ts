import { IconDefinition } from '../types';
declare const FileTextTwoTone: IconDefinition;
export default FileTextTwoTone;

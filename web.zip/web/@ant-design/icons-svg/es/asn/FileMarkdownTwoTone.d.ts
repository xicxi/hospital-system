import { IconDefinition } from '../types';
declare const FileMarkdownTwoTone: IconDefinition;
export default FileMarkdownTwoTone;

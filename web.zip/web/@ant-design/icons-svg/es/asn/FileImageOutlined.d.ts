import { IconDefinition } from '../types';
declare const FileImageOutlined: IconDefinition;
export default FileImageOutlined;

import { IconDefinition } from '../types';
declare const FilePptOutlined: IconDefinition;
export default FilePptOutlined;

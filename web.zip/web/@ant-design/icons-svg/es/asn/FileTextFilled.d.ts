import { IconDefinition } from '../types';
declare const FileTextFilled: IconDefinition;
export default FileTextFilled;

import { IconDefinition } from '../types';
declare const AccountBookOutlined: IconDefinition;
export default AccountBookOutlined;

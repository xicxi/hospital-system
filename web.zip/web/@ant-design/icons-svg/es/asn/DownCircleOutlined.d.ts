import { IconDefinition } from '../types';
declare const DownCircleOutlined: IconDefinition;
export default DownCircleOutlined;

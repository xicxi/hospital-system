import { IconDefinition } from '../types';
declare const CompassFilled: IconDefinition;
export default CompassFilled;

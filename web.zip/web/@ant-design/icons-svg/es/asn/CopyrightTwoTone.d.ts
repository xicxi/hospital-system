import { IconDefinition } from '../types';
declare const CopyrightTwoTone: IconDefinition;
export default CopyrightTwoTone;

import { IconDefinition } from '../types';
declare const FileZipTwoTone: IconDefinition;
export default FileZipTwoTone;

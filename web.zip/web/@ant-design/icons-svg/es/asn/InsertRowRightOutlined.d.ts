import { IconDefinition } from '../types';
declare const InsertRowRightOutlined: IconDefinition;
export default InsertRowRightOutlined;

import { IconDefinition } from '../types';
declare const FileExcelTwoTone: IconDefinition;
export default FileExcelTwoTone;

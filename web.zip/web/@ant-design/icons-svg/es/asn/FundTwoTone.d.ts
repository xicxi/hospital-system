import { IconDefinition } from '../types';
declare const FundTwoTone: IconDefinition;
export default FundTwoTone;

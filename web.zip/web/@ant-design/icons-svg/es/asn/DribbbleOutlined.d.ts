import { IconDefinition } from '../types';
declare const DribbbleOutlined: IconDefinition;
export default DribbbleOutlined;

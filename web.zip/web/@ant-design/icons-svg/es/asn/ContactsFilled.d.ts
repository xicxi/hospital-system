import { IconDefinition } from '../types';
declare const ContactsFilled: IconDefinition;
export default ContactsFilled;

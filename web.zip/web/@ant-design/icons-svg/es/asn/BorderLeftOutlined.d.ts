import { IconDefinition } from '../types';
declare const BorderLeftOutlined: IconDefinition;
export default BorderLeftOutlined;

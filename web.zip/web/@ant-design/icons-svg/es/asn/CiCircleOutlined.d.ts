import { IconDefinition } from '../types';
declare const CiCircleOutlined: IconDefinition;
export default CiCircleOutlined;

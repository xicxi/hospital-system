import { IconDefinition } from '../types';
declare const EyeInvisibleFilled: IconDefinition;
export default EyeInvisibleFilled;

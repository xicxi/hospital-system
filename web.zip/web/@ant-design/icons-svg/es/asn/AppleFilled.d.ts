import { IconDefinition } from '../types';
declare const AppleFilled: IconDefinition;
export default AppleFilled;

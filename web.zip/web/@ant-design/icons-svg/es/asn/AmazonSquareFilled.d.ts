import { IconDefinition } from '../types';
declare const AmazonSquareFilled: IconDefinition;
export default AmazonSquareFilled;

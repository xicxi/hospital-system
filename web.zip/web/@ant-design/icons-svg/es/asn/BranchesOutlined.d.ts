import { IconDefinition } from '../types';
declare const BranchesOutlined: IconDefinition;
export default BranchesOutlined;

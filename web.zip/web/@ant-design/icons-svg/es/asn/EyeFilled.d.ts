import { IconDefinition } from '../types';
declare const EyeFilled: IconDefinition;
export default EyeFilled;

import { IconDefinition } from '../types';
declare const ControlFilled: IconDefinition;
export default ControlFilled;

import { IconDefinition } from '../types';
declare const CloudUploadOutlined: IconDefinition;
export default CloudUploadOutlined;

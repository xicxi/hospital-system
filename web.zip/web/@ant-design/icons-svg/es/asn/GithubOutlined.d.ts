import { IconDefinition } from '../types';
declare const GithubOutlined: IconDefinition;
export default GithubOutlined;

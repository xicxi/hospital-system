import { IconDefinition } from '../types';
declare const FlagOutlined: IconDefinition;
export default FlagOutlined;

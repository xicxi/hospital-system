import { IconDefinition } from '../types';
declare const LayoutOutlined: IconDefinition;
export default LayoutOutlined;

import { IconDefinition } from '../types';
declare const CiCircleFilled: IconDefinition;
export default CiCircleFilled;

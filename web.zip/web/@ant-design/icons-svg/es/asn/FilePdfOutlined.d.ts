import { IconDefinition } from '../types';
declare const FilePdfOutlined: IconDefinition;
export default FilePdfOutlined;

import { IconDefinition } from '../types';
declare const AlertTwoTone: IconDefinition;
export default AlertTwoTone;

import { IconDefinition } from '../types';
declare const LeftCircleTwoTone: IconDefinition;
export default LeftCircleTwoTone;

import { IconDefinition } from '../types';
declare const DollarTwoTone: IconDefinition;
export default DollarTwoTone;

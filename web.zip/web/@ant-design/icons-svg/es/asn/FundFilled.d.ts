import { IconDefinition } from '../types';
declare const FundFilled: IconDefinition;
export default FundFilled;

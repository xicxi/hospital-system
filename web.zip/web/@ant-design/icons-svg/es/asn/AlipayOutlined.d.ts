import { IconDefinition } from '../types';
declare const AlipayOutlined: IconDefinition;
export default AlipayOutlined;

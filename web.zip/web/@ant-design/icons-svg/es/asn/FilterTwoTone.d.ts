import { IconDefinition } from '../types';
declare const FilterTwoTone: IconDefinition;
export default FilterTwoTone;

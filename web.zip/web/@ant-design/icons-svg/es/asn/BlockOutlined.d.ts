import { IconDefinition } from '../types';
declare const BlockOutlined: IconDefinition;
export default BlockOutlined;

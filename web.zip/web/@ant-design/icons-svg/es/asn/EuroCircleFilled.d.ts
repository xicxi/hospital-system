import { IconDefinition } from '../types';
declare const EuroCircleFilled: IconDefinition;
export default EuroCircleFilled;

import { IconDefinition } from '../types';
declare const AppstoreOutlined: IconDefinition;
export default AppstoreOutlined;

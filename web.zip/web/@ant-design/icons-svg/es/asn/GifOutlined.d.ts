import { IconDefinition } from '../types';
declare const GifOutlined: IconDefinition;
export default GifOutlined;

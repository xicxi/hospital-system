import { IconDefinition } from '../types';
declare const BehanceSquareFilled: IconDefinition;
export default BehanceSquareFilled;

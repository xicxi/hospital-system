import { IconDefinition } from '../types';
declare const CaretDownOutlined: IconDefinition;
export default CaretDownOutlined;

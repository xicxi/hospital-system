import { IconDefinition } from '../types';
declare const BellOutlined: IconDefinition;
export default BellOutlined;

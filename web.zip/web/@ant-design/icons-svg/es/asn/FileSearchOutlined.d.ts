import { IconDefinition } from '../types';
declare const FileSearchOutlined: IconDefinition;
export default FileSearchOutlined;

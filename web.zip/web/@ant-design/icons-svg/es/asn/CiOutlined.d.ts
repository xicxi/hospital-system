import { IconDefinition } from '../types';
declare const CiOutlined: IconDefinition;
export default CiOutlined;

import { IconDefinition } from '../types';
declare const EuroTwoTone: IconDefinition;
export default EuroTwoTone;

import { IconDefinition } from '../types';
declare const CompassTwoTone: IconDefinition;
export default CompassTwoTone;

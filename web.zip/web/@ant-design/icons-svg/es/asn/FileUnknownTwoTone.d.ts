import { IconDefinition } from '../types';
declare const FileUnknownTwoTone: IconDefinition;
export default FileUnknownTwoTone;

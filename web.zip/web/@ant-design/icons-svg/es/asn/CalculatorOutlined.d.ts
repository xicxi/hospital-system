import { IconDefinition } from '../types';
declare const CalculatorOutlined: IconDefinition;
export default CalculatorOutlined;

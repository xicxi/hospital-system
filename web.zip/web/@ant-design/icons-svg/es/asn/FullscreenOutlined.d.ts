import { IconDefinition } from '../types';
declare const FullscreenOutlined: IconDefinition;
export default FullscreenOutlined;

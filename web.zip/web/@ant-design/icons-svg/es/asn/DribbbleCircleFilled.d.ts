import { IconDefinition } from '../types';
declare const DribbbleCircleFilled: IconDefinition;
export default DribbbleCircleFilled;

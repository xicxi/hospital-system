import { IconDefinition } from '../types';
declare const CopyrightCircleFilled: IconDefinition;
export default CopyrightCircleFilled;

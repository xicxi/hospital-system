import { IconDefinition } from '../types';
declare const CaretLeftFilled: IconDefinition;
export default CaretLeftFilled;

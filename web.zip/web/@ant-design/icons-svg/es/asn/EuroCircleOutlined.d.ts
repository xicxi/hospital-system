import { IconDefinition } from '../types';
declare const EuroCircleOutlined: IconDefinition;
export default EuroCircleOutlined;

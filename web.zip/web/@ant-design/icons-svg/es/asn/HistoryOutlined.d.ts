import { IconDefinition } from '../types';
declare const HistoryOutlined: IconDefinition;
export default HistoryOutlined;

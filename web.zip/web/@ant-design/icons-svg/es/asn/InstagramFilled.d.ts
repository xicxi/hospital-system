import { IconDefinition } from '../types';
declare const InstagramFilled: IconDefinition;
export default InstagramFilled;

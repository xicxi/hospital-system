import { IconDefinition } from '../types';
declare const CarTwoTone: IconDefinition;
export default CarTwoTone;

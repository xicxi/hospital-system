import { IconDefinition } from '../types';
declare const BulbOutlined: IconDefinition;
export default BulbOutlined;

import { IconDefinition } from '../types';
declare const ApartmentOutlined: IconDefinition;
export default ApartmentOutlined;

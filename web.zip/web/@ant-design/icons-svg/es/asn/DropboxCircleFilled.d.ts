import { IconDefinition } from '../types';
declare const DropboxCircleFilled: IconDefinition;
export default DropboxCircleFilled;

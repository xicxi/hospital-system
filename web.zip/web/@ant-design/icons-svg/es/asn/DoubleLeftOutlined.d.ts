import { IconDefinition } from '../types';
declare const DoubleLeftOutlined: IconDefinition;
export default DoubleLeftOutlined;

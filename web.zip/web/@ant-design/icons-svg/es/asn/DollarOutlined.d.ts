import { IconDefinition } from '../types';
declare const DollarOutlined: IconDefinition;
export default DollarOutlined;

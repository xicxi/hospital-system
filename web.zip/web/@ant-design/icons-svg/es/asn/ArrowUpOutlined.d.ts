import { IconDefinition } from '../types';
declare const ArrowUpOutlined: IconDefinition;
export default ArrowUpOutlined;

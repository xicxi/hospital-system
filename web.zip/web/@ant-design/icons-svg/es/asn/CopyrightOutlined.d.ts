import { IconDefinition } from '../types';
declare const CopyrightOutlined: IconDefinition;
export default CopyrightOutlined;

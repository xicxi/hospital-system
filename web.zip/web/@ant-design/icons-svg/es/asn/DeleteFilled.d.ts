import { IconDefinition } from '../types';
declare const DeleteFilled: IconDefinition;
export default DeleteFilled;

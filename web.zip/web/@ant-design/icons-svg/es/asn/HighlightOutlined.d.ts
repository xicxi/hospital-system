import { IconDefinition } from '../types';
declare const HighlightOutlined: IconDefinition;
export default HighlightOutlined;

import { IconDefinition } from '../types';
declare const EuroOutlined: IconDefinition;
export default EuroOutlined;

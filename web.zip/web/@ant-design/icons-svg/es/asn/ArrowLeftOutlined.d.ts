import { IconDefinition } from '../types';
declare const ArrowLeftOutlined: IconDefinition;
export default ArrowLeftOutlined;

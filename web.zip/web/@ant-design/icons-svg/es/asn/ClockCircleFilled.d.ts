import { IconDefinition } from '../types';
declare const ClockCircleFilled: IconDefinition;
export default ClockCircleFilled;

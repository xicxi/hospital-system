import { IconDefinition } from '../types';
declare const CrownTwoTone: IconDefinition;
export default CrownTwoTone;

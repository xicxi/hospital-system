import { IconDefinition } from '../types';
declare const HourglassOutlined: IconDefinition;
export default HourglassOutlined;

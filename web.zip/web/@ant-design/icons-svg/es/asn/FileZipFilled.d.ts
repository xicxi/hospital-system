import { IconDefinition } from '../types';
declare const FileZipFilled: IconDefinition;
export default FileZipFilled;

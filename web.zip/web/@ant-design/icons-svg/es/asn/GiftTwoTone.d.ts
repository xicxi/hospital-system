import { IconDefinition } from '../types';
declare const GiftTwoTone: IconDefinition;
export default GiftTwoTone;

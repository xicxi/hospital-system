import { IconDefinition } from '../types';
declare const FileMarkdownFilled: IconDefinition;
export default FileMarkdownFilled;

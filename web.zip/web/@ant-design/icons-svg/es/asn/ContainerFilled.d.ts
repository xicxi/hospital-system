import { IconDefinition } from '../types';
declare const ContainerFilled: IconDefinition;
export default ContainerFilled;

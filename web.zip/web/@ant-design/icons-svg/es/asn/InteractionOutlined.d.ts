import { IconDefinition } from '../types';
declare const InteractionOutlined: IconDefinition;
export default InteractionOutlined;

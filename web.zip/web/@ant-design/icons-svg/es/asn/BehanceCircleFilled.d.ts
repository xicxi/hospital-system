import { IconDefinition } from '../types';
declare const BehanceCircleFilled: IconDefinition;
export default BehanceCircleFilled;

import { IconDefinition } from '../types';
declare const FileZipOutlined: IconDefinition;
export default FileZipOutlined;

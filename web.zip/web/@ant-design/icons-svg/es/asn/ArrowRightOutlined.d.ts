import { IconDefinition } from '../types';
declare const ArrowRightOutlined: IconDefinition;
export default ArrowRightOutlined;

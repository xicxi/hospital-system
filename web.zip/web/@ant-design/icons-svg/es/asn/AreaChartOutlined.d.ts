import { IconDefinition } from '../types';
declare const AreaChartOutlined: IconDefinition;
export default AreaChartOutlined;

import { IconDefinition } from '../types';
declare const EnvironmentOutlined: IconDefinition;
export default EnvironmentOutlined;

import { IconDefinition } from '../types';
declare const AmazonOutlined: IconDefinition;
export default AmazonOutlined;

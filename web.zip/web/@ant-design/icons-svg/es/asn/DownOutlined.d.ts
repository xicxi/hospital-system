import { IconDefinition } from '../types';
declare const DownOutlined: IconDefinition;
export default DownOutlined;

import { IconDefinition } from '../types';
declare const FrownTwoTone: IconDefinition;
export default FrownTwoTone;

import { IconDefinition } from '../types';
declare const CreditCardOutlined: IconDefinition;
export default CreditCardOutlined;

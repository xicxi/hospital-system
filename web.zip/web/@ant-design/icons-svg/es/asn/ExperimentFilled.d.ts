import { IconDefinition } from '../types';
declare const ExperimentFilled: IconDefinition;
export default ExperimentFilled;

import { IconDefinition } from '../types';
declare const DislikeOutlined: IconDefinition;
export default DislikeOutlined;

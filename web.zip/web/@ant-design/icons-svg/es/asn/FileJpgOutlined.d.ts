import { IconDefinition } from '../types';
declare const FileJpgOutlined: IconDefinition;
export default FileJpgOutlined;

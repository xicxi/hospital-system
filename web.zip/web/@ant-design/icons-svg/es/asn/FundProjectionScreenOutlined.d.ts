import { IconDefinition } from '../types';
declare const FundProjectionScreenOutlined: IconDefinition;
export default FundProjectionScreenOutlined;

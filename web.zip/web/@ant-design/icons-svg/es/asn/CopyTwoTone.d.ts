import { IconDefinition } from '../types';
declare const CopyTwoTone: IconDefinition;
export default CopyTwoTone;

import { IconDefinition } from '../types';
declare const AppstoreAddOutlined: IconDefinition;
export default AppstoreAddOutlined;

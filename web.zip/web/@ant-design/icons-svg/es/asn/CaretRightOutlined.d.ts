import { IconDefinition } from '../types';
declare const CaretRightOutlined: IconDefinition;
export default CaretRightOutlined;

import { IconDefinition } from '../types';
declare const BorderVerticleOutlined: IconDefinition;
export default BorderVerticleOutlined;

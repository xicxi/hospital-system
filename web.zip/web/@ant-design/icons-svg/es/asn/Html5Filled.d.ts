import { IconDefinition } from '../types';
declare const Html5Filled: IconDefinition;
export default Html5Filled;

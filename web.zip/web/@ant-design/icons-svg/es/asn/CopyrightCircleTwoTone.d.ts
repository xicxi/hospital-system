import { IconDefinition } from '../types';
declare const CopyrightCircleTwoTone: IconDefinition;
export default CopyrightCircleTwoTone;

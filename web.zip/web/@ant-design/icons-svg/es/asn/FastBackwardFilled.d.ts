import { IconDefinition } from '../types';
declare const FastBackwardFilled: IconDefinition;
export default FastBackwardFilled;

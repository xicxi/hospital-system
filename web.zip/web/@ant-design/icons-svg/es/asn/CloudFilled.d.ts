import { IconDefinition } from '../types';
declare const CloudFilled: IconDefinition;
export default CloudFilled;

import { IconDefinition } from '../types';
declare const BorderRightOutlined: IconDefinition;
export default BorderRightOutlined;

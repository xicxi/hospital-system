import { IconDefinition } from '../types';
declare const CoffeeOutlined: IconDefinition;
export default CoffeeOutlined;

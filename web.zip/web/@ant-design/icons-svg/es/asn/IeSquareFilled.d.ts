import { IconDefinition } from '../types';
declare const IeSquareFilled: IconDefinition;
export default IeSquareFilled;

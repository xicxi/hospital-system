import { IconDefinition } from '../types';
declare const InfoCircleTwoTone: IconDefinition;
export default InfoCircleTwoTone;

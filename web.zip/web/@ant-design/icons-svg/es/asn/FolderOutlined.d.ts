import { IconDefinition } from '../types';
declare const FolderOutlined: IconDefinition;
export default FolderOutlined;

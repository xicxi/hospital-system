import { IconDefinition } from '../types';
declare const ExpandAltOutlined: IconDefinition;
export default ExpandAltOutlined;

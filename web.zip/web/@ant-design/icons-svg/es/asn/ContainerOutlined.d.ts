import { IconDefinition } from '../types';
declare const ContainerOutlined: IconDefinition;
export default ContainerOutlined;

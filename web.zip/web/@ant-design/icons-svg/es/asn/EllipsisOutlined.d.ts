import { IconDefinition } from '../types';
declare const EllipsisOutlined: IconDefinition;
export default EllipsisOutlined;

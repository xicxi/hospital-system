import { IconDefinition } from '../types';
declare const CalendarFilled: IconDefinition;
export default CalendarFilled;

import { IconDefinition } from '../types';
declare const BehanceOutlined: IconDefinition;
export default BehanceOutlined;

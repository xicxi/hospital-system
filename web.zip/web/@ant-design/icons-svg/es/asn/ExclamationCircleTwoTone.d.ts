import { IconDefinition } from '../types';
declare const ExclamationCircleTwoTone: IconDefinition;
export default ExclamationCircleTwoTone;

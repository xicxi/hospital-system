import { IconDefinition } from '../types';
declare const FlagTwoTone: IconDefinition;
export default FlagTwoTone;

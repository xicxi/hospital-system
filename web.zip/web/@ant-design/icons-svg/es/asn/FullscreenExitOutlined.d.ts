import { IconDefinition } from '../types';
declare const FullscreenExitOutlined: IconDefinition;
export default FullscreenExitOutlined;

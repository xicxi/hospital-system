import { IconDefinition } from '../types';
declare const ChromeOutlined: IconDefinition;
export default ChromeOutlined;

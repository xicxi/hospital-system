import { IconDefinition } from '../types';
declare const FolderOpenFilled: IconDefinition;
export default FolderOpenFilled;

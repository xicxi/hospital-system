import { IconDefinition } from '../types';
declare const GatewayOutlined: IconDefinition;
export default GatewayOutlined;

import { IconDefinition } from '../types';
declare const FileWordFilled: IconDefinition;
export default FileWordFilled;

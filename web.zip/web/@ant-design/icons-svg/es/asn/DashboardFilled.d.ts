import { IconDefinition } from '../types';
declare const DashboardFilled: IconDefinition;
export default DashboardFilled;

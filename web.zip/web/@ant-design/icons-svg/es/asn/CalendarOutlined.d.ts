import { IconDefinition } from '../types';
declare const CalendarOutlined: IconDefinition;
export default CalendarOutlined;

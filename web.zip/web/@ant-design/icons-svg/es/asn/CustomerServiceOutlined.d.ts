import { IconDefinition } from '../types';
declare const CustomerServiceOutlined: IconDefinition;
export default CustomerServiceOutlined;

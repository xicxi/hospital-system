import { IconDefinition } from '../types';
declare const CloseCircleFilled: IconDefinition;
export default CloseCircleFilled;

import { IconDefinition } from '../types';
declare const HeartFilled: IconDefinition;
export default HeartFilled;

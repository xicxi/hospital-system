import { IconDefinition } from '../types';
declare const CreditCardTwoTone: IconDefinition;
export default CreditCardTwoTone;

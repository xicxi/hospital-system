import { IconDefinition } from '../types';
declare const AlipayCircleOutlined: IconDefinition;
export default AlipayCircleOutlined;

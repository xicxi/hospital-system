import { IconDefinition } from '../types';
declare const ClockCircleOutlined: IconDefinition;
export default ClockCircleOutlined;

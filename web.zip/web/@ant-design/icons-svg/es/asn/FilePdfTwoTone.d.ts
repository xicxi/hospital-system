import { IconDefinition } from '../types';
declare const FilePdfTwoTone: IconDefinition;
export default FilePdfTwoTone;

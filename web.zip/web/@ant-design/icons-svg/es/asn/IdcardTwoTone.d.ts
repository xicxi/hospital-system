import { IconDefinition } from '../types';
declare const IdcardTwoTone: IconDefinition;
export default IdcardTwoTone;

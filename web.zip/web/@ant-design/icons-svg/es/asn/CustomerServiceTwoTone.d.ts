import { IconDefinition } from '../types';
declare const CustomerServiceTwoTone: IconDefinition;
export default CustomerServiceTwoTone;

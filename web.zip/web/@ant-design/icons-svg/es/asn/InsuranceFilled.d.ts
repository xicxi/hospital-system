import { IconDefinition } from '../types';
declare const InsuranceFilled: IconDefinition;
export default InsuranceFilled;

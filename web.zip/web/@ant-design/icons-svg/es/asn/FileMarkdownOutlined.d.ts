import { IconDefinition } from '../types';
declare const FileMarkdownOutlined: IconDefinition;
export default FileMarkdownOutlined;

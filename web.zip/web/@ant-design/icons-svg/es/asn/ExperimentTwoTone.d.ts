import { IconDefinition } from '../types';
declare const ExperimentTwoTone: IconDefinition;
export default ExperimentTwoTone;

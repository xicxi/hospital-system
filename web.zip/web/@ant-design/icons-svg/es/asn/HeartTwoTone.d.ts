import { IconDefinition } from '../types';
declare const HeartTwoTone: IconDefinition;
export default HeartTwoTone;

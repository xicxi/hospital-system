import { IconDefinition } from '../types';
declare const DotChartOutlined: IconDefinition;
export default DotChartOutlined;

import { IconDefinition } from '../types';
declare const DatabaseOutlined: IconDefinition;
export default DatabaseOutlined;

import { IconDefinition } from '../types';
declare const InteractionTwoTone: IconDefinition;
export default InteractionTwoTone;

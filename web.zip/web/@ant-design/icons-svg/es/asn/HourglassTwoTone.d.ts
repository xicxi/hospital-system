import { IconDefinition } from '../types';
declare const HourglassTwoTone: IconDefinition;
export default HourglassTwoTone;

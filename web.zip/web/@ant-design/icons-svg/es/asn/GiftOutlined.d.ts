import { IconDefinition } from '../types';
declare const GiftOutlined: IconDefinition;
export default GiftOutlined;

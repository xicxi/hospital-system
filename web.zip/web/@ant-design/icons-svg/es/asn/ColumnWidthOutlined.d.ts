import { IconDefinition } from '../types';
declare const ColumnWidthOutlined: IconDefinition;
export default ColumnWidthOutlined;

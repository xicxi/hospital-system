import { IconDefinition } from '../types';
declare const BankTwoTone: IconDefinition;
export default BankTwoTone;

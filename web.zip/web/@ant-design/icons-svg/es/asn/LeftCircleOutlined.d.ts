import { IconDefinition } from '../types';
declare const LeftCircleOutlined: IconDefinition;
export default LeftCircleOutlined;

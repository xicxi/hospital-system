import { IconDefinition } from '../types';
declare const BehanceSquareOutlined: IconDefinition;
export default BehanceSquareOutlined;

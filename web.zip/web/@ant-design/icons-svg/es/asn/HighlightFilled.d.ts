import { IconDefinition } from '../types';
declare const HighlightFilled: IconDefinition;
export default HighlightFilled;

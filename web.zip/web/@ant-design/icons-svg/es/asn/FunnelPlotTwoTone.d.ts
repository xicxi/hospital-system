import { IconDefinition } from '../types';
declare const FunnelPlotTwoTone: IconDefinition;
export default FunnelPlotTwoTone;

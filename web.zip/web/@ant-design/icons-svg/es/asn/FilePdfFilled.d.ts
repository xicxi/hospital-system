import { IconDefinition } from '../types';
declare const FilePdfFilled: IconDefinition;
export default FilePdfFilled;

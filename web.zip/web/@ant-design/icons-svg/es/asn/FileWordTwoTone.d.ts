import { IconDefinition } from '../types';
declare const FileWordTwoTone: IconDefinition;
export default FileWordTwoTone;

import { IconDefinition } from '../types';
declare const DesktopOutlined: IconDefinition;
export default DesktopOutlined;

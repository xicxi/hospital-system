import { IconDefinition } from '../types';
declare const LeftOutlined: IconDefinition;
export default LeftOutlined;

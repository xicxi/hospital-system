import { IconDefinition } from '../types';
declare const FilterFilled: IconDefinition;
export default FilterFilled;

import { IconDefinition } from '../types';
declare const AccountBookTwoTone: IconDefinition;
export default AccountBookTwoTone;

import { IconDefinition } from '../types';
declare const DingtalkSquareFilled: IconDefinition;
export default DingtalkSquareFilled;

import { IconDefinition } from '../types';
declare const EyeInvisibleOutlined: IconDefinition;
export default EyeInvisibleOutlined;

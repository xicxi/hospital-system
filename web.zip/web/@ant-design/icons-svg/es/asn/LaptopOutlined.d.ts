import { IconDefinition } from '../types';
declare const LaptopOutlined: IconDefinition;
export default LaptopOutlined;

import { IconDefinition } from '../types';
declare const CameraOutlined: IconDefinition;
export default CameraOutlined;

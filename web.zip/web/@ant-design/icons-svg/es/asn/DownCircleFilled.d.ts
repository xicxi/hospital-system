import { IconDefinition } from '../types';
declare const DownCircleFilled: IconDefinition;
export default DownCircleFilled;

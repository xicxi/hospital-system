import { IconDefinition } from '../types';
declare const FileExclamationFilled: IconDefinition;
export default FileExclamationFilled;

import { IconDefinition } from '../types';
declare const HolderOutlined: IconDefinition;
export default HolderOutlined;

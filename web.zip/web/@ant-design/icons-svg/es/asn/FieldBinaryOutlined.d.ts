import { IconDefinition } from '../types';
declare const FieldBinaryOutlined: IconDefinition;
export default FieldBinaryOutlined;

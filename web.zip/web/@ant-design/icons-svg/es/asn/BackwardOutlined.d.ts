import { IconDefinition } from '../types';
declare const BackwardOutlined: IconDefinition;
export default BackwardOutlined;

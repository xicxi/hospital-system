import { IconDefinition } from '../types';
declare const HeatMapOutlined: IconDefinition;
export default HeatMapOutlined;

import { IconDefinition } from '../types';
declare const DribbbleSquareFilled: IconDefinition;
export default DribbbleSquareFilled;

import { IconDefinition } from '../types';
declare const ImportOutlined: IconDefinition;
export default ImportOutlined;

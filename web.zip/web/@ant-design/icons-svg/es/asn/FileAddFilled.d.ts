import { IconDefinition } from '../types';
declare const FileAddFilled: IconDefinition;
export default FileAddFilled;

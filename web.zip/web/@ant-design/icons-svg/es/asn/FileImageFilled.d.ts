import { IconDefinition } from '../types';
declare const FileImageFilled: IconDefinition;
export default FileImageFilled;

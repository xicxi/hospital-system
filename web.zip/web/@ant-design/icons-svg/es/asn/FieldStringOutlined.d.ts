import { IconDefinition } from '../types';
declare const FieldStringOutlined: IconDefinition;
export default FieldStringOutlined;

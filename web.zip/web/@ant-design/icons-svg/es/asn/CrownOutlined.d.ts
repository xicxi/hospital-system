import { IconDefinition } from '../types';
declare const CrownOutlined: IconDefinition;
export default CrownOutlined;

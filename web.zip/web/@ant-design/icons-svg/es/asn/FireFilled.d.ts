import { IconDefinition } from '../types';
declare const FireFilled: IconDefinition;
export default FireFilled;

import { IconDefinition } from '../types';
declare const EyeInvisibleTwoTone: IconDefinition;
export default EyeInvisibleTwoTone;

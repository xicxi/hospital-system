import { IconDefinition } from '../types';
declare const CloudSyncOutlined: IconDefinition;
export default CloudSyncOutlined;

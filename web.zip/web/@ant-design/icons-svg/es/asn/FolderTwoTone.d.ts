import { IconDefinition } from '../types';
declare const FolderTwoTone: IconDefinition;
export default FolderTwoTone;

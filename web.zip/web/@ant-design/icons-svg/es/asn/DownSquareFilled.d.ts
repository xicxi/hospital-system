import { IconDefinition } from '../types';
declare const DownSquareFilled: IconDefinition;
export default DownSquareFilled;

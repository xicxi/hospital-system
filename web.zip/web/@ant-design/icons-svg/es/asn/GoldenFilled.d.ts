import { IconDefinition } from '../types';
declare const GoldenFilled: IconDefinition;
export default GoldenFilled;

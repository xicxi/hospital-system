import { IconDefinition } from '../types';
declare const DatabaseFilled: IconDefinition;
export default DatabaseFilled;

import { IconDefinition } from '../types';
declare const HddFilled: IconDefinition;
export default HddFilled;

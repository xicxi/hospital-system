import { IconDefinition } from '../types';
declare const CiCircleTwoTone: IconDefinition;
export default CiCircleTwoTone;

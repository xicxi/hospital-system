import { IconDefinition } from '../types';
declare const FrownOutlined: IconDefinition;
export default FrownOutlined;

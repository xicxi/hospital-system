import { IconDefinition } from '../types';
declare const BankOutlined: IconDefinition;
export default BankOutlined;

import { IconDefinition } from '../types';
declare const CodepenOutlined: IconDefinition;
export default CodepenOutlined;

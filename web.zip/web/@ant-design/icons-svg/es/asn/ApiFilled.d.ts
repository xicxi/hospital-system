import { IconDefinition } from '../types';
declare const ApiFilled: IconDefinition;
export default ApiFilled;

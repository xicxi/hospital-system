import { IconDefinition } from '../types';
declare const CrownFilled: IconDefinition;
export default CrownFilled;

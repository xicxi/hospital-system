import { IconDefinition } from '../types';
declare const EnterOutlined: IconDefinition;
export default EnterOutlined;

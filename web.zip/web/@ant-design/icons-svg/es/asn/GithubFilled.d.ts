import { IconDefinition } from '../types';
declare const GithubFilled: IconDefinition;
export default GithubFilled;

import { IconDefinition } from '../types';
declare const FileTextOutlined: IconDefinition;
export default FileTextOutlined;

import { IconDefinition } from '../types';
declare const AmazonCircleFilled: IconDefinition;
export default AmazonCircleFilled;

import { IconDefinition } from '../types';
declare const BoxPlotFilled: IconDefinition;
export default BoxPlotFilled;

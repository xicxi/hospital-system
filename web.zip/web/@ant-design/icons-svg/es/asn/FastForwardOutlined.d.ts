import { IconDefinition } from '../types';
declare const FastForwardOutlined: IconDefinition;
export default FastForwardOutlined;

import { IconDefinition } from '../types';
declare const FolderFilled: IconDefinition;
export default FolderFilled;

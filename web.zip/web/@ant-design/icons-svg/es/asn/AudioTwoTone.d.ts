import { IconDefinition } from '../types';
declare const AudioTwoTone: IconDefinition;
export default AudioTwoTone;

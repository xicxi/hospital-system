import { IconDefinition } from '../types';
declare const FunnelPlotOutlined: IconDefinition;
export default FunnelPlotOutlined;

import { IconDefinition } from '../types';
declare const InfoCircleOutlined: IconDefinition;
export default InfoCircleOutlined;

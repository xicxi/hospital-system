import { IconDefinition } from '../types';
declare const HeartOutlined: IconDefinition;
export default HeartOutlined;

import { IconDefinition } from '../types';
declare const InboxOutlined: IconDefinition;
export default InboxOutlined;

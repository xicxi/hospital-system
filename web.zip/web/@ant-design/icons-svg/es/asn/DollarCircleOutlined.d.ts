import { IconDefinition } from '../types';
declare const DollarCircleOutlined: IconDefinition;
export default DollarCircleOutlined;

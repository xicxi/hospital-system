import { IconDefinition } from '../types';
declare const GoldTwoTone: IconDefinition;
export default GoldTwoTone;

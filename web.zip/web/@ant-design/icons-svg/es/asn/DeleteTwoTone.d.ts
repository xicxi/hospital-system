import { IconDefinition } from '../types';
declare const DeleteTwoTone: IconDefinition;
export default DeleteTwoTone;

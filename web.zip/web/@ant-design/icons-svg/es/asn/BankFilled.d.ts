import { IconDefinition } from '../types';
declare const BankFilled: IconDefinition;
export default BankFilled;

import { IconDefinition } from '../types';
declare const ExceptionOutlined: IconDefinition;
export default ExceptionOutlined;

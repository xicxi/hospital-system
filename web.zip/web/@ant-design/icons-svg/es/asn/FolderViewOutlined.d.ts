import { IconDefinition } from '../types';
declare const FolderViewOutlined: IconDefinition;
export default FolderViewOutlined;

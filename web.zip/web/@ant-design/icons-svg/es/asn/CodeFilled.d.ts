import { IconDefinition } from '../types';
declare const CodeFilled: IconDefinition;
export default CodeFilled;

import { IconDefinition } from '../types';
declare const GitlabOutlined: IconDefinition;
export default GitlabOutlined;

import { IconDefinition } from '../types';
declare const CopyFilled: IconDefinition;
export default CopyFilled;

import { IconDefinition } from '../types';
declare const BulbTwoTone: IconDefinition;
export default BulbTwoTone;

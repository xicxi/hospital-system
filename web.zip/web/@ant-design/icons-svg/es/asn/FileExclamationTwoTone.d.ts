import { IconDefinition } from '../types';
declare const FileExclamationTwoTone: IconDefinition;
export default FileExclamationTwoTone;

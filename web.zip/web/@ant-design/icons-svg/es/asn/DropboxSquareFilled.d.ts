import { IconDefinition } from '../types';
declare const DropboxSquareFilled: IconDefinition;
export default DropboxSquareFilled;

import { IconDefinition } from '../types';
declare const AppstoreTwoTone: IconDefinition;
export default AppstoreTwoTone;

import { IconDefinition } from '../types';
declare const CompressOutlined: IconDefinition;
export default CompressOutlined;

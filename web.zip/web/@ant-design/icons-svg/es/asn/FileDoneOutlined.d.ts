import { IconDefinition } from '../types';
declare const FileDoneOutlined: IconDefinition;
export default FileDoneOutlined;

import { IconDefinition } from '../types';
declare const HddTwoTone: IconDefinition;
export default HddTwoTone;

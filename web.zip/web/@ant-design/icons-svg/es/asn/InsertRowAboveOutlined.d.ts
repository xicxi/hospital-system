import { IconDefinition } from '../types';
declare const InsertRowAboveOutlined: IconDefinition;
export default InsertRowAboveOutlined;

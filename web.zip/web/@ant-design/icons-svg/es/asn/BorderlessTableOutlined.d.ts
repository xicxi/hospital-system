import { IconDefinition } from '../types';
declare const BorderlessTableOutlined: IconDefinition;
export default BorderlessTableOutlined;

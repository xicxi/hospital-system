import { IconDefinition } from '../types';
declare const ForwardOutlined: IconDefinition;
export default ForwardOutlined;

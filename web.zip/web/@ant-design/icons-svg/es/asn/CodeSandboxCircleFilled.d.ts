import { IconDefinition } from '../types';
declare const CodeSandboxCircleFilled: IconDefinition;
export default CodeSandboxCircleFilled;

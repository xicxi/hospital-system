import { IconDefinition } from '../types';
declare const AlignCenterOutlined: IconDefinition;
export default AlignCenterOutlined;

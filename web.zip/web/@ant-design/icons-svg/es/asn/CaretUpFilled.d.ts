import { IconDefinition } from '../types';
declare const CaretUpFilled: IconDefinition;
export default CaretUpFilled;

import { IconDefinition } from '../types';
declare const AlignLeftOutlined: IconDefinition;
export default AlignLeftOutlined;

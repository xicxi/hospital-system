import { IconDefinition } from '../types';
declare const DeploymentUnitOutlined: IconDefinition;
export default DeploymentUnitOutlined;

import { IconDefinition } from '../types';
declare const DownSquareTwoTone: IconDefinition;
export default DownSquareTwoTone;

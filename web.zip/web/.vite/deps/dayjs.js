import {
  require_dayjs_min
} from "./chunk-XMOLR7NX.js";
import "./chunk-4EOJPDL2.js";
export default require_dayjs_min();
//# sourceMappingURL=dayjs.js.map

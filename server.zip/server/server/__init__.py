import pymysql
pymysql.install_as_MySQLdb()

print("===============install pymysql==============")
declare const Empty: {
    (): JSX.Element;
    PRESENTED_IMAGE_DEFAULT: boolean;
};
export default Empty;

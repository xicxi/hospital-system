import type { PickerLocale } from '../generatePicker';
declare const locale: PickerLocale;
export default locale;

import type { TagProps } from '../tag';
export default function PickerTag(props: TagProps, { slots, attrs }: {
    slots: any;
    attrs: any;
}): JSX.Element;

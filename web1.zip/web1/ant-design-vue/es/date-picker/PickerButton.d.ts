import type { FunctionalComponent } from 'vue';
import type { ButtonProps } from '../button';
declare const PickerButton: FunctionalComponent<ButtonProps>;
export default PickerButton;

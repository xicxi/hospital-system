declare const _default: () => (callback: () => void) => void;
/**
 * Always trigger latest once when call multiple time
 */
export default _default;

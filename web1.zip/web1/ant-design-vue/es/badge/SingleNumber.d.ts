export interface UnitNumberProps {
    prefixCls: string;
    value: string | number;
    offset?: number;
    current?: boolean;
}
declare const _default: import("vue").DefineComponent<{
    prefixCls: StringConstructor;
    value: StringConstructor;
    count: NumberConstructor;
}, () => JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    prefixCls: StringConstructor;
    value: StringConstructor;
    count: NumberConstructor;
}>>, {}>;
export default _default;

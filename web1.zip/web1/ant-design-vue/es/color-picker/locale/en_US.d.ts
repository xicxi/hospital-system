declare var _default: {
    'btn:save': string;
    'btn:cancel': string;
    'btn:clear': string;
};
export default _default;

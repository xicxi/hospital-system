import idID from '../../date-picker/locale/id_ID';
export default idID;

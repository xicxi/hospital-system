import koKR from '../../date-picker/locale/ko_KR';
export default koKR;

import jaJP from '../../date-picker/locale/ja_JP';
export default jaJP;

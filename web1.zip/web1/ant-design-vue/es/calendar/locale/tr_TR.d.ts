import trTR from '../../date-picker/locale/tr_TR';
export default trTR;

import ukUA from '../../date-picker/locale/uk_UA';
export default ukUA;

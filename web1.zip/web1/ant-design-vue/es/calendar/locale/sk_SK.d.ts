import skSK from '../../date-picker/locale/sk_SK';
export default skSK;

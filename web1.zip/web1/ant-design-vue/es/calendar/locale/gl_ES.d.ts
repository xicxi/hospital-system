import glES from '../../date-picker/locale/gl_ES';
export default glES;

import itIT from '../../date-picker/locale/it_IT';
export default itIT;

import kmKH from '../../date-picker/locale/km_KH';
export default kmKH;

import csCZ from '../../date-picker/locale/cs_CZ';
export default csCZ;

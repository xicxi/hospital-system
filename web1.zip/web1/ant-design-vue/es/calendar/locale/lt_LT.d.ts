import ltLT from '../../date-picker/locale/lt_LT';
export default ltLT;

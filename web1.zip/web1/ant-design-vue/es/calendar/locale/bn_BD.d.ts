import bnBD from '../../date-picker/locale/bn_BD';
export default bnBD;

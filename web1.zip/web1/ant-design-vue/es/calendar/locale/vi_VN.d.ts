import viVN from '../../date-picker/locale/vi_VN';
export default viVN;

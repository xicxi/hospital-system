import heIL from '../../date-picker/locale/he_IL';
export default heIL;

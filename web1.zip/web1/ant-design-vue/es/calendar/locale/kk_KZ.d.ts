import kkKZ from '../../date-picker/locale/kk_KZ';
export default kkKZ;

declare const _default: import("vue").DefineComponent<{
    prefixCls: StringConstructor;
    loading: (ObjectConstructor | BooleanConstructor)[];
    existIcon: BooleanConstructor;
}, () => JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    prefixCls: StringConstructor;
    loading: (ObjectConstructor | BooleanConstructor)[];
    existIcon: BooleanConstructor;
}>>, {
    existIcon: boolean;
}>;
export default _default;
